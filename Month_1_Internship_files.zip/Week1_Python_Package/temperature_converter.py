# Temperature Converter
choice = input("Convert from (C/F): ").strip().upper()
temp = float(input("Enter the temperature: "))

if choice == "C":
    converted = (temp * 9/5) + 32
    print(f"{temp}°C is {converted:.2f}°F")
elif choice == "F":
    converted = (temp - 32) * 5/9
    print(f"{temp}°F is {converted:.2f}°C")
else:
    print("Invalid choice!")
