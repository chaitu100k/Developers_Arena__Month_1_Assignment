# Average Temperature Calculator
temps = []
n = int(input("How many temperature readings? "))

for i in range(n):
    t = float(input(f"Enter temperature {i+1} in °C: "))
    temps.append(t)

average = sum(temps) / len(temps)
print(f"Average temperature: {average:.2f}°C")
