# Week 3: NumPy and Pandas for Data Manipulation

import numpy as np
import pandas as pd

# --- Theory Examples ---

# 1. NumPy Arrays
arr = np.array([1, 2, 3, 4])
print("NumPy Array:", arr)

# 2. NumPy Operations
arr_squared = arr ** 2
print("Array Squared:", arr_squared)

# 3. Broadcasting
arr_broadcast = arr + 10
print("Broadcasting Example:", arr_broadcast)

# 4. Pandas Series
series = pd.Series([10, 20, 30], index=["a", "b", "c"])
print("Pandas Series:
", series)

# 5. Pandas DataFrame
data = {
    "Name": ["Alice", "Bob", "Charlie"],
    "Age": [25, 30, 35],
    "Score": [85, 90, 95]
}
df = pd.DataFrame(data)
print("Pandas DataFrame:
", df)

# 6. Indexing in DataFrame
print("Row by index:
", df.iloc[1])
print("Column by name:
", df["Score"])

# 7. Data Grouping
grouped = df.groupby("Age")["Score"].mean()
print("Grouped by Age:
", grouped)

# --- Hands-On Exercises ---

# NumPy: Element-wise addition
arr2 = np.array([5, 6, 7, 8])
sum_array = arr + arr2
print("Element-wise Sum:", sum_array)

# Pandas: Filter rows where Score > 85
filtered_df = df[df["Score"] > 85]
print("Filtered DataFrame:
", filtered_df)

# --- Client Project: Clean and Aggregate Dataset ---

# Sample dataset with missing values
data_project = {
    "Name": ["Alice", "Bob", "Charlie", "David", None],
    "Department": ["HR", "IT", "IT", "Finance", "Finance"],
    "Salary": [50000, 60000, None, 55000, 58000]
}

df_project = pd.DataFrame(data_project)
print("Original Dataset:
", df_project)

# Remove missing values
df_cleaned = df_project.dropna()
print("Cleaned Dataset:
", df_cleaned)

# Calculate average salary by department
avg_salary = df_cleaned.groupby("Department")["Salary"].mean()
print("Average Salary by Department:
", avg_salary)
