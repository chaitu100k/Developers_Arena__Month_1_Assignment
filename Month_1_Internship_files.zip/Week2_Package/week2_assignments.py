# Week 2: Data Structures and Functions

# --- Theory Examples ---

# 1. Lists (ordered, mutable)
fruits = ["apple", "banana", "cherry"]
fruits.append("mango")
print("List Example:", fruits)

# 2. Tuples (ordered, immutable)
coordinates = (10, 20)
print("Tuple Example:", coordinates)

# 3. Dictionaries (key-value pairs)
student = {"name": "Alice", "age": 20}
student["grade"] = "A"
print("Dictionary Example:", student)

# 4. Sets (unordered, unique elements)
colors = {"red", "blue", "red"}  # duplicate "red" will be removed
colors.add("green")
print("Set Example:", colors)

# 5. Functions
def greet(name):
    return f"Hello {name}"
print("Function Example:", greet("Bob"))

# 6. Lambda Functions
square = lambda x: x**2
print("Lambda Example (square of 5):", square(5))

# 7. Recursion
def factorial(n):
    return 1 if n <= 1 else n * factorial(n-1)
print("Recursion Example (factorial of 5):", factorial(5))

# 8. List Comprehension
squares = [x**2 for x in range(5)]
print("List Comprehension Example:", squares)

# --- Hands-On Exercises ---

# Sum of squares
numbers = [1, 2, 3, 4]
sum_of_squares = sum(x**2 for x in numbers)
print("Sum of squares:", sum_of_squares)

# Filtering even numbers
nums = [1, 2, 3, 4, 5]
evens = [n for n in nums if n % 2 == 0]
print("Filtered even numbers:", evens)

# --- Client Project: Data Cleaning Script ---
def clean_data(data):
    # Remove duplicates
    data = list(set(data))
    
    # Filter: keep only non-empty strings
    data = [item for item in data if isinstance(item, str) and item.strip()]
    
    return data

raw_data = ["apple", "banana", "", "apple", " ", "orange", None]
cleaned_data = clean_data(raw_data)
print("Cleaned Data:", cleaned_data)
